0.0.8: Reverted Armored Raven.  
0.0.7: Armored Raven now activates target's Graze. Fixed Breaking News, Anything is Newsworthy not working in other languages.  
Fixed Panorama not working correctly. Fixed Spell Card text. Removed Breaking News' additional damage.  
0.0.6: Added Korean localization. Contribution of *raspberry Caffeine Monster*.  
0.0.5: Fixed Bunbunmaru Printer text.  
0.0.4: Now supports localization. Fixed Protection Paper not applying block per level.  
Take Picture adds Newspaper to top of the draw pile, draw 1 card.  
0.0.3: Illusionary Dominance damage 1 -> 9(12), Upgrade to attack each enemy.  
Added missing descriptions and icons for status effects. Fixed Reign of Wind applying wrong buff and Spell Card portrait.  
0.0.2: Added Reign of Wind. Fixed Aya's portrait not shown.  
0.0.1: Alpha released.  