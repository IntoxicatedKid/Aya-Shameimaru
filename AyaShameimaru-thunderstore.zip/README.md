## Aya Shameimaru Playable Character  
Alpha version: Missing a lot of cards, balancing and details.  
More descriptions will be added later.  

Aya portrait by dairi

Korean translation by raspberry Caffeine Monster